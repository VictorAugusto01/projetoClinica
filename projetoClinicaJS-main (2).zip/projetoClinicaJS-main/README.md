# Projeto Clinica JS
- Participantes do grupo:<br>
    Arthur Augusto Quaglio Lima | 38624311<br>
    Gabriel Roberto De Oliveira Silva | 38682740<br>
    Omar Hatoum | 37723235<br>
    Victor Neves Augusto | 37901508<br>
    Gustavo Vinicius de Souza | 37090046<br>
    Vinicius Nóbrega Damiana | 38949920<br>

- Sobre:<br>
Projeto de um sistema de clínicas utilizando JS, HTML, CSS
